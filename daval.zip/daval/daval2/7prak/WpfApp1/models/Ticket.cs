﻿using System;

namespace WpfApp1.Models
{
    internal class Ticket
    {
        public string Id { get; set; }

        public string Description { get; set; }

        public string Category { get; set; }

        public string Priority { get; set; }

        public string Status { get; set; }

        public DateTime CreatdAt { get; set; }
    }
}
