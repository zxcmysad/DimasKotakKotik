﻿using System.Security.Cryptography.X509Certificates;

namespace WpfApp1.Models
{
    public class Users
    {
        public int Id { get; set; }

        public string Login { get; set; }

        public string FullName { get; set; }

        public string Role { get; set; }
    }
}
