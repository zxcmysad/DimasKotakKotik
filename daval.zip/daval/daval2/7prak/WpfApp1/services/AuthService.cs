﻿namespace WpfApp1.Services
{
    public class AuthService
    {

    }
}
