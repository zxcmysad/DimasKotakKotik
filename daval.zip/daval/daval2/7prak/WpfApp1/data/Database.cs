﻿namespace WpfApp1.Data
{
    public class Database
    {

    }
}
